#!/system/bin/sh
# ============================================================
#  核心逻辑: 扫描并写入电池节点
#  被 service.sh(开机) 和 action.sh(手动) 共同调用
# ============================================================

MODDIR=${MODDIR:-/data/adb/modules/battery_unlock_nx616j}
[ -f "$MODDIR/config.sh" ] && . "$MODDIR/config.sh"

LOG=${LOG_FILE:-/data/local/tmp/battery_unlock.log}

# 默认兜底
[ -z "$TARGET_CHARGE_FULL" ] && TARGET_CHARGE_FULL=6860000
[ -z "$TARGET_CHARGE_FULL_DESIGN" ] && TARGET_CHARGE_FULL_DESIGN=6860000
[ -z "$ENABLE_VOLTAGE_UNLOCK" ] && ENABLE_VOLTAGE_UNLOCK=0
[ -z "$TARGET_VOLTAGE_MAX" ] && TARGET_VOLTAGE_MAX=4550000

# 关 selinux，否则写 sysfs 常被拦
setenforce 0 2>/dev/null

log() {
  echo "$1" >> "$LOG" 2>/dev/null
  echo "$1"
}

echo "" >> "$LOG" 2>/dev/null
log "===== $(date '+%F %T') ====="
log "selinux: $(getenforce 2>/dev/null)"
log "id: $(id 2>/dev/null)"
log "目标容量: $TARGET_CHARGE_FULL uAh"
log "电压解锁: $ENABLE_VOLTAGE_UNLOCK (目标 ${TARGET_VOLTAGE_MAX} uV)"
log "----------------------------------------"

FOUND=0
WROTE_FULL=0
WROTE_VOLT=0

for d in /sys/class/power_supply/*/; do
  [ -d "$d" ] || continue
  name=$(basename "$d")
  log "[ $name ]"

  # ---------- 读: 先摸清现状 ----------
  for n in charge_full charge_full_design voltage_max voltage_max_design capacity; do
    f="${d}${n}"
    if [ -f "$f" ]; then
      log "   R  $n = $(cat "$f" 2>/dev/null)"
      FOUND=1
    fi
  done

  # ---------- 写: 满充容量 ----------
  cf="${d}charge_full"
  if [ -f "$cf" ]; then
    old=$(cat "$cf" 2>/dev/null)
    echo "$TARGET_CHARGE_FULL" > "$cf" 2>/dev/null
    new=$(cat "$cf" 2>/dev/null)
    if [ "$new" = "$TARGET_CHARGE_FULL" ]; then
      log "   W  charge_full: $old -> $new   [OK]"
      WROTE_FULL=1
    else
      log "   W  charge_full: 写入失败，仍为 $new  [只读/内核锁死]"
    fi
  fi

  # ---------- 写: 设计容量 ----------
  cfd="${d}charge_full_design"
  if [ -f "$cfd" ]; then
    echo "$TARGET_CHARGE_FULL_DESIGN" > "$cfd" 2>/dev/null
    log "   W  charge_full_design -> $(cat "$cfd" 2>/dev/null)"
  fi

  # ---------- 写: 截止电压(默认关闭) ----------
  if [ "$ENABLE_VOLTAGE_UNLOCK" = "1" ]; then
    vm="${d}voltage_max"
    if [ -f "$vm" ]; then
      oldv=$(cat "$vm" 2>/dev/null)
      echo "$TARGET_VOLTAGE_MAX" > "$vm" 2>/dev/null
      newv=$(cat "$vm" 2>/dev/null)
      if [ "$newv" = "$TARGET_VOLTAGE_MAX" ]; then
        log "   W  voltage_max: $oldv -> $newv   [OK]"
        WROTE_VOLT=1
      else
        log "   W  voltage_max: 写入失败，仍为 $newv"
      fi
    fi
  else
    log "   -  voltage_max: 未启用(ENABLE_VOLTAGE_UNLOCK=0)"
  fi

  log ""
done

log "========================================"
if [ "$FOUND" = "0" ]; then
  log "!! 没找到任何 power_supply 节点 — root 未生效?"
else
  if [ "$WROTE_FULL" = "1" ]; then
    log ">> 容量写入成功: ${TARGET_CHARGE_FULL} uAh"
  else
    log ">> 容量写入失败: 内核把 charge_full 设为只读"
    log ">>   -> 此路不通，需要改 dtbo 或编译内核"
  fi
  [ "$ENABLE_VOLTAGE_UNLOCK" = "1" ] && {
    [ "$WROTE_VOLT" = "1" ] && log ">> 电压写入成功" || log ">> 电压写入失败"
  }
fi
log "日志: $LOG"

# 同步一份到 sdcard 方便查看
cp "$LOG" "${LOG_SDCARD}" 2>/dev/null

exit 0
