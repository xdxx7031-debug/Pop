#!/system/bin/sh
# 开机自动执行 (late_start service: boot_completed 之后)
MODDIR=${0%/*}
. "$MODDIR/config.sh"
sleep "${BOOT_DELAY:-15}"
sh "$MODDIR/common/apply.sh"
