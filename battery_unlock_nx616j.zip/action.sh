#!/system/bin/sh
# 手动执行: 在 APatch / KernelSU / Magisk 里点模块右下角「执行」按钮
# 立刻生效，不用重启。用来验证到底写没写进去。
MODDIR=${0%/*}
sh "$MODDIR/common/apply.sh"
