#!/system/bin/sh
# 卸载时把节点恢复成出厂值，避免留下半改状态
setenforce 0 2>/dev/null
for d in /sys/class/power_supply/*/; do
  [ -d "$d" ] || continue
  # 容量: 恢复原电 3800mAh
  [ -f "${d}charge_full" ] && echo 3800000 > "${d}charge_full" 2>/dev/null
  [ -f "${d}charge_full_design" ] && echo 3800000 > "${d}charge_full_design" 2>/dev/null
  # 电压: 恢复 4.4V
  [ -f "${d}voltage_max" ] && echo 4400000 > "${d}voltage_max" 2>/dev/null
done
rm -f /data/local/tmp/battery_unlock.log
rm -f /sdcard/Download/battery_unlock.log
exit 0
