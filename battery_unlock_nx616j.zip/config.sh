#!/system/bin/sh
# ============================================================
#  努比亚X (nx616j) + 小米17 电芯  解容模块 — 配置
#  改完这个文件，不需要重装模块：
#    · 改容量 -> 在 APatch 点模块「执行」，或重启
#    · 改电压开关 -> 同上
# ============================================================

# ---- 满充容量 (uAh) = mAh × 1000 ----
# 小米17 电芯: 额定 6860mAh / 典型 7000mAh
# 填额定值，留安全余量。填大了等于教电量计过充。
TARGET_CHARGE_FULL=6860000

# ---- 设计容量 (uAh) ----
# 只影响「电池健康度」显示的分母，不参与充电控制
TARGET_CHARGE_FULL_DESIGN=6860000

# ---- 充电截止电压 (uV)  【默认关闭，见下】----
# 小米17 硅碳电芯平台是 4.55V；努比亚X(2018) 原电约 4.35~4.4V
# 硬件(PMI8998) 很可能达不到 4.55V。盲目改会顶着过压充。
# 想开的话: 先跑 action 看 voltage_max 当前值，确认硬件能力后再改 1
ENABLE_VOLTAGE_UNLOCK=0
TARGET_VOLTAGE_MAX=4550000

# ---- 日志 ----
LOG_FILE=/data/local/tmp/battery_unlock.log
LOG_SDCARD=/sdcard/Download/battery_unlock.log

# ---- 开机延迟(秒) : 等 power_supply 节点就绪 ----
BOOT_DELAY=15
